import { $, $$, escapeHtml as esc } from './ui/dom.js';
import {
  GAMES,
  gameOf,
  isSwiss,
  swissStandings,
  nextSwissRound,
  manualSwissMatch,
} from './swiss-core.mjs';
import {
  initCutForm,
  readCutForm,
  renderCut,
  canFinish,
  hasCut,
  checkCutPlan,
  cutMatches,
  matchLabel,
  matchMinutes,
} from './top-cut-ui.js';
const eventStorageKey =
  'duel-arena-v1' +
  (localStorage.getItem('kingdom-store')
    ? ':' + localStorage.getItem('kingdom-store')
    : '');
let events = [];
try {
  events = JSON.parse(localStorage.getItem(eventStorageKey) || '[]');
} catch {}
let activeGame = 'yugioh';
try {
  const stored = localStorage.getItem('duel-arena-game');
  if (Object.hasOwn(GAMES, stored)) activeGame = stored;
} catch {}
window.arenaGame = activeGame;
let timerContext = '',
  filter = 'all',
  current = '',
  seconds = 3000,
  interval = null;
const uid = () => crypto.randomUUID();
function notify(t) {
  $('#toast').textContent = t;
  $('#toast').style.display = 'block';
  setTimeout(() => ($('#toast').style.display = 'none'), 4500);
}
function save() {
  localStorage.setItem(eventStorageKey, JSON.stringify(events));
  render();
  window.arenaCloud.queue(events);
}
function view(id) {
  $$('.view').forEach((v) => (v.hidden = v.id !== id));
  $$('nav button').forEach((b) => b.classList.toggle('active', b.dataset.view === id));
  render();
}
$$('nav button').forEach((b) => (b.onclick = () => view(b.dataset.view)));
$('#guide').onclick = $('#policy').onclick = () => view('rules');
$('#new').onclick = () => {
  $('#eventForm').reset();
  $('#dialogGame').textContent = GAMES[activeGame].name;
  $('#eventForm [name=format]').innerHTML = GAMES[activeGame].formats
    .map(
      (f) => /* HTML */ `
        <option>${esc(f)}</option>
      `,
    )
    .join('');
  $('#eventForm [name=roundMinutes]').value = GAMES[activeGame].minutes;
  initCutForm($('#eventForm'), activeGame);
  $('#eventDialog').showModal();
};
$('#close').onclick = () => $('#eventDialog').close();
$('#eventForm').onsubmit = (e) => {
  e.preventDefault();
  const f = new FormData(e.target);
  const ev = {
    id: uid(),
    game: activeGame,
    roundMinutes: +f.get('roundMinutes'),
    name: f.get('name').trim(),
    date: f.get('date'),
    time: f.get('time'),
    location: f.get('location').trim(),
    capacity: +f.get('capacity'),
    rounds: +f.get('rounds'),
    format: f.get('format'),
    status: 'open',
    players: [],
    matches: [],
  };
  if (!ev.name || !ev.location) return;
  try {
    readCutForm(e.target, ev);
  } catch (error) {
    return notify(error.message);
  }
  events.unshift(ev);
  current = ev.id;
  save();
  $('#eventDialog').close();
  notify('Torneio criado. Sua arena está pronta!');
};
$$('[data-filter]').forEach(
  (b) =>
    (b.onclick = () => {
      filter = b.dataset.filter;
      $$('[data-filter]').forEach((x) => x.classList.toggle('selected', x === b));
      render();
    }),
);
$('#search').oninput = render;
function render() {
  const visible = events.filter((e) => gameOf(e) === activeGame);
  renderGameChrome();
  const names = { open: 'Inscrições abertas', live: 'Em andamento', done: 'Encerrado' };
  $('#statEvents').textContent = visible.length;
  $('#statLive').textContent = visible.filter((e) => e.status === 'live').length;
  $('#statPlayers').textContent = visible.reduce((a, e) => a + e.players.length, 0);
  $('#count').textContent = visible.length;
  let list = visible.filter(
    (e) =>
      (filter === 'all' || e.status === filter) &&
      `${e.name} ${e.location}`.toLowerCase().includes($('#search').value.toLowerCase()),
  );
  $('#eventList').innerHTML = list.length
    ? list
        .map((e) => {
          const date = new Date(e.date + 'T12:00:00');
          return /* HTML */ `
            <article class="event-row">
              <div class="date-tile">
                ${esc(
                  date
                    .toLocaleDateString('pt-BR', { month: 'short' })
                    .replace('.', '')
                    .toUpperCase(),
                )}
                <strong>${date.getDate()}</strong>
              </div>
              <div class="event-info">
                <h3>${esc(e.name)}</h3>
                <p>
                  ⌖ ${esc(e.location)} &nbsp; · &nbsp; ${esc(e.time)} &nbsp; · &nbsp;
                  ${esc(e.format)}
                </p>
                <p>
                  ${e.players.length}/${e.capacity} duelistas &nbsp; · &nbsp; ${e.rounds}
                  rodadas suíças ·
                  ${hasCut(e)
                    ? e.cutPlan.size
                      ? 'Top ' + e.cutPlan.size
                      : 'Sem corte nesta faixa'
                    : 'Somente suíço'}
                </p>
              </div>
              <span class="badge ${e.status}">${names[e.status]}</span>
              <div class="event-actions">
                <button class="secondary" data-manage="${esc(e.id)}">Gerenciar ↗</button>
                <button class="text" data-status="${esc(e.id)}">
                  ${e.status === 'open'
                    ? 'Iniciar'
                    : e.status === 'live'
                      ? 'Encerrar'
                      : 'Reabrir'}
                </button>
              </div>
            </article>
          `;
        })
        .join('')
    : /* HTML */ `
        <div class="empty">
          <div class="empty-icon">♜</div>
          <h3>
            ${visible.length
              ? 'Nenhum torneio encontrado'
              : 'Sua próxima arena está esperando'}
          </h3>
          <p>
            ${visible.length
              ? 'Experimente outra busca ou filtro.'
              : 'Crie seu primeiro torneio e convide os duelistas da sua comunidade.'}
          </p>
          ${visible.length
            ? ''
            : '<button class="text" id="emptyCreate">＋ Criar meu primeiro torneio</button>'}
        </div>
      `;
  if ($('#emptyCreate')) $('#emptyCreate').onclick = () => $('#new').click();
  $$('[data-manage]').forEach(
    (b) =>
      (b.onclick = () => {
        current = b.dataset.manage;
        view('players');
      }),
  );
  $$('[data-status]').forEach(
    (b) =>
      (b.onclick = () => {
        const e = visible.find((x) => x.id === b.dataset.status);
        if (e.status === 'open' && e.players.length < (isSwiss(e) ? 2 : 4))
          return notify(
            isSwiss(e)
              ? 'Cadastre pelo menos 2 participantes para iniciar.'
              : 'Cadastre pelo menos 4 duelistas para iniciar.',
          );
        if (e.status === 'open' && hasCut(e)) {
          try {
            checkCutPlan({ ...e, status: 'live' });
          } catch (error) {
            return notify(
              error.message +
                ' Abra Gerenciar → Mesas e resultados para ajustar o plano.',
            );
          }
        }
        if (e.status === 'live' && !canFinish(e))
          return notify(
            'Conclua todas as rodadas e a final do Top Cut antes de encerrar.',
          );
        e.status =
          e.status === 'open'
            ? 'live'
            : e.status === 'live'
              ? 'done'
              : hasCut(e)
                ? 'live'
                : 'open';
        save();
      }),
  );
  if (!visible.some((e) => e.id === current)) current = visible[0]?.id || '';
  ['#playerEvent', '#tableEvent'].forEach((s) => {
    $(s).innerHTML = visible.length
      ? visible
          .map(
            (e) => /* HTML */ `
              <option value="${esc(e.id)}">${esc(e.name)}</option>
            `,
          )
          .join('')
      : '<option value="">Crie um torneio primeiro</option>';
    $(s).value = current;
  });
  const e = visible.find((x) => x.id === current);
  $('#playerForm').hidden = !e;
  $('#matchForm').hidden =
    !e ||
    e.status !== 'live' ||
    !!cutMatches(e).length ||
    document.body.dataset.storeRole === 'judge';
  $('#manualPairings').hidden = $('#matchForm').hidden;
  $('#round').max = e?.rounds || 20;
  $('#swissControls').hidden =
    !e || (!isSwiss(e) && !hasCut(e)) || !!cutMatches(e).length;
  syncTimer(e);
  $('#playerList').innerHTML = e
    ? /* HTML */ `
        <div class="panel">
          <b>${e.players.length} de ${e.capacity} vagas preenchidas</b>
          ${e.players.length
            ? '<table><thead><tr><th>Duelista</th><th>Inscrição</th><th>ID do ranking</th></tr></thead><tbody>' +
              e.players
                .map(
                  (p, i) => /* HTML */ `
                    <tr>
                      <td>${esc(p.name)}</td>
                      <td>#${String(i + 1).padStart(3, '0')}</td>
                      <td>
                        <div class="ranking-id-editor">
                          <input
                            aria-label="ID do ranking de ${esc(p.name)}"
                            data-ranking-input="${esc(p.id)}"
                            value="${esc(p.rankingId || '')}"
                            maxlength="40"
                            placeholder="Ex.: ARENA-001"
                          />
                          <button class="secondary" data-ranking-save="${esc(p.id)}">
                            Salvar ID
                          </button>
                        </div>
                      </td>
                    </tr>
                  `,
                )
                .join('') +
              '</tbody></table>'
            : '<p>Nenhum duelista cadastrado. Adicione o primeiro acima.</p>'}
        </div>
      `
    : '';
  $$('[data-ranking-save]').forEach(
    (button) =>
      (button.onclick = () => {
        if (!window.arenaCloud.isReady()) return notify('Aguarde a conexão.');
        const input = $$('[data-ranking-input]').find(
          (x) => x.dataset.rankingInput === button.dataset.rankingSave,
        );
        const rankingId = input.value.trim().toUpperCase();
        if (!/^[A-Z0-9_-]{1,40}$/.test(rankingId))
          return notify('Use de 1 a 40 letras, números, hífen ou sublinhado.');
        if (
          e.players.some(
            (p) =>
              p.id !== button.dataset.rankingSave &&
              p.rankingId?.toUpperCase() === rankingId,
          )
        )
          return notify('Este ID já está no torneio.');
        e.players.find((p) => p.id === button.dataset.rankingSave).rankingId = rankingId;
        save();
        notify('ID atualizado. O ranking será recalculado ao salvar.');
      }),
  );
  ['#playerA', '#playerB'].forEach(
    (s) =>
      ($(s).innerHTML =
        '<option value="">Selecione</option>' +
        (e
          ? e.players
              .map(
                (p) => /* HTML */ `
                  <option value="${esc(p.id)}">${esc(p.name)}</option>
                `,
              )
              .join('')
          : '')),
  );
  if (e && (isSwiss(e) || hasCut(e)))
    $('#playerB').insertAdjacentHTML(
      'beforeend',
      '<option value="__bye__">BYE · sem adversário</option>',
    );
  $('#matches').innerHTML = e?.matches.length
    ? e.matches
        .map((m, i) => {
          const a = esc(e.players.find((p) => p.id === m.a)?.name || ''),
            b = esc(e.players.find((p) => p.id === m.b)?.name || '');
          return /* HTML */ `
            <div class="event-row">
              <span class="badge">${matchLabel(e, m)} · Mesa ${m.table}</span>
              <b>${a} ${m.result === 'bye' ? '· BYE' : '× ' + b}</b>
              ${m.result === 'void'
                ? '<span class="badge">Vaga sem classificado</span>'
                : m.result === 'bye'
                  ? m.phase === 'cut'
                    ? '<span class="badge">Avança por bye · sem pontos mensais</span>'
                    : '<span class="badge">Vitória · 3 pontos</span>'
                  : /* HTML */ `
                      <select
                        aria-label="Resultado mesa ${m.table}, rodada ${m.round}"
                        data-match="${i}"
                        ${e.status === 'done' ||
                        (hasCut(e) && cutMatches(e).some((next) => next.round > m.round))
                          ? 'disabled'
                          : ''}
                      >
                        <option value="">Resultado pendente</option>
                        <option value="a">Vitória de A</option>
                        <option value="b">Vitória de B</option>
                        ${m.phase === 'cut'
                          ? activeGame === 'yugioh' &&
                            m.round < e.rounds + Math.log2(e.cutPlan.size)
                            ? '<option value="double">Derrota dupla · ambos eliminados</option>'
                            : ''
                          : isSwiss(e)
                            ? '<option value="draw">Empate</option>'
                            : '<option value="double">Derrota dupla</option>'}
                      </select>
                    `}
            </div>
          `;
        })
        .join('')
    : '<div class="empty"><p>As mesas aparecerão aqui após o cadastro dos confrontos.</p></div>';
  if (e && cutMatches(e).length)
    $('#matches').innerHTML =
      '<details class="panel"><summary>Histórico de mesas e resultados do suíço</summary>' +
      $('#matches').innerHTML +
      '</details>';
  $$('[data-match]').forEach((s) => {
    s.value = e.matches[+s.dataset.match].result || '';
    s.onchange = () => {
      e.matches[+s.dataset.match].result = s.value;
      save();
    };
  });
  renderStandings(e);
  renderCut(e, { container: $('#topCutPanel'), save, notify });
}

$('#playerEvent').onchange = $('#tableEvent').onchange = (e) => {
  current = e.target.value;
  render();
};
$('#playerForm').onsubmit = (ev) => {
  ev.preventDefault();
  const e = events.find((e) => e.id === current),
    name = $('#playerName').value.trim();
  if (!e || !name) return;
  if (e.status !== 'open') return notify('As inscrições estão fechadas.');
  if (e.players.length >= e.capacity)
    return notify('A capacidade do torneio foi atingida.');
  if (e.players.some((p) => p.name.toLowerCase() === name.toLowerCase()))
    return notify('Este duelista já está cadastrado.');
  const rankingId = $('#playerRankingId').value.trim().toUpperCase();
  if (!/^[A-Z0-9_-]{1,40}$/.test(rankingId))
    return notify('Informe um ID do ranking válido.');
  if (e.players.some((p) => p.rankingId?.toUpperCase() === rankingId))
    return notify('Este ID já está cadastrado no torneio.');
  e.players.push({ id: uid(), name, rankingId });
  $('#playerRankingId').value = '';
  $('#playerName').value = '';
  save();
  notify('Duelista cadastrado.');
};
$('#matchForm').onsubmit = (ev) => {
  ev.preventDefault();
  if (!window.arenaCloud.isReady()) return notify('Aguarde a conexão com o banco.');
  const e = events.find((e) => e.id === current);
  if (!e) return;
  try {
    const match = manualSwissMatch(e, {
      a: $('#playerA').value,
      b: $('#playerB').value === '__bye__' ? null : $('#playerB').value,
      round: +$('#round').value,
    });
    e.matches.push(match);
    save();
    notify(
      'Mesa ' + match.table + ' da rodada ' + match.round + ' cadastrada manualmente.',
    );
  } catch (error) {
    notify(error.message);
  }
};
function drawClock() {
  $('#clock').textContent =
    `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
}
$('#timer').onclick = () => {
  if (interval) {
    clearInterval(interval);
    interval = null;
    $('#timer').textContent = 'Continuar';
  } else {
    if (!seconds) return;
    $('#timer').textContent = 'Pausar';
    interval = setInterval(() => {
      seconds--;
      drawClock();
      if (seconds <= 0) {
        clearInterval(interval);
        interval = null;
        $('#timer').textContent = 'Encerrado';
        notify('Tempo encerrado. Chame a arbitragem para o procedimento oficial.');
      }
    }, 1000);
  }
};
$('#reset').onclick = () => {
  clearInterval(interval);
  interval = null;
  resetClock(events.find((e) => e.id === current));
  $('#timer').textContent = 'Iniciar';
};
$('#deckForm').onsubmit = (e) => {
  e.preventDefault();
  const f = new FormData(e.target),
    a = +f.get('main'),
    b = +f.get('extra'),
    c = +f.get('side');
  $('#deckResult').textContent =
    [a, b, c].every(Number.isInteger) &&
    a >= 40 &&
    a <= 60 &&
    b >= 0 &&
    b <= 15 &&
    c >= 0 &&
    c <= 15
      ? '✓ Quantidades válidas. Confira também as cartas e a lista vigente.'
      : 'Revise as quantidades: Main 40–60, Extra 0–15 e Side 0–15.';
};
$('#export').onclick = () => {
  const url = URL.createObjectURL(
    new Blob([JSON.stringify({ version: 1, events }, null, 2)], {
      type: 'application/json',
    }),
  );
  const a = document.createElement('a');
  a.href = url;
  a.download = 'duelist-kingdom-backup.json';
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
};
$('#import').onchange = async (e) => {
  try {
    const data = JSON.parse(await e.target.files[0].text());
    if (data.version !== 1 || !Array.isArray(data.events))
      throw Error('Formato inválido.');
    const { validateEvent } = await import('./ranking-core.mjs');
    const ids = new Set();
    for (const event of data.events) {
      validateEvent(event);
      if (ids.has(event.id)) throw Error('Torneio repetido no backup.');
      ids.add(event.id);
    }
    const fresh = data.events.filter((x) => !events.some((e) => e.id === x.id));
    events.push(...fresh);
    save();
    notify(
      `${fresh.length} torneio(s) importado(s). Eventos existentes foram preservados.`,
    );
  } catch (error) {
    notify('Backup inválido: ' + (error.message || 'Revise o arquivo.'));
  }
  e.target.value = '';
};
function renderGameChrome() {
  window.arenaGame = activeGame;
  window.applyGameWorld?.(activeGame);
  const swiss = activeGame !== 'yugioh',
    profile = GAMES[activeGame];
  $$('.game-tabs button[data-game]').forEach((b) => {
    b.setAttribute('aria-selected', String(b.dataset.game === activeGame));
    b.tabIndex = b.dataset.game === activeGame ? 0 : -1;
  });
  $('#gameWorkspace').setAttribute('aria-labelledby', 'game-' + activeGame);
  $('#activeGameLabel').textContent = profile.name.toUpperCase() + ' · TCG';
  $('#statMinutes').textContent = profile.minutes;
  $('#policySummary').textContent = swiss
    ? 'Perfil suíço tradicional da liga · consulte também os documentos do jogo.'
    : 'Consulte a política KDE-US v2.5 e os documentos específicos do seu evento.';
  $('#pairingIntro').textContent = swiss
    ? 'Escolha os confrontos manualmente ou gere a próxima rodada automaticamente.'
    : 'Escolha os confrontos manualmente. Em Suíço + Top Cut, a geração automática também está disponível.';
  $('#matchNotice').textContent = swiss
    ? 'Suíço tradicional da liga · Vitória 3, empate 1, derrota 0. Desempates: Buchholz e Sonneborn–Berger. Bye vale 3 pontos.'
    : 'Classificação por AA → BBB → CCC → DDD, do maior para o menor. Resultados pendentes não entram nos cálculos; derrota dupla conta como derrota para ambos.';
  $('#yugiohTiebreaks').hidden = swiss;
  $('#swissTiebreaks').hidden = !swiss;
  $('#yugiohRules').hidden = swiss;
  $('#swissRules').hidden = !swiss;
  $('#swissRulesTitle').textContent = profile.name + ' · Suíço tradicional da liga';
  $('#gameRulesLink').href = profile.link;
  $('#monthlyNotice').textContent = swiss
    ? 'Ranking mensal de ' +
      profile.name +
      ': soma de pontos suíços dos torneios encerrados deste jogo no mês. Top Cut não soma pontos. Vitória ou bye = 3; empate = 1; derrota = 0. Pontuações iguais compartilham a posição.'
    : 'Regra da liga de Yu-Gi-Oh!: soma de pontos suíços dos torneios encerrados no mês. Top Cut não soma pontos. Vitória = 3; derrota ou double loss = 0. Pontuação igual mantém a mesma posição. Os desempates AA/BBB/CCC/DDD continuam em cada torneio.';
}
function setGame(game) {
  if (!Object.hasOwn(GAMES, game)) return;
  activeGame = game;
  window.arenaGame = game;
  current = '';
  filter = 'all';
  $('#search').value = '';
  $$('[data-filter]').forEach((b) =>
    b.classList.toggle('selected', b.dataset.filter === 'all'),
  );
  try {
    localStorage.setItem('duel-arena-game', game);
  } catch {}
  render();
  document.dispatchEvent(new Event('arena-game-changed'));
}
$$('.game-tabs button[data-game]').forEach((b) => {
  b.onclick = () => setGame(b.dataset.game);
  b.onkeydown = (e) => {
    const keys = Object.keys(GAMES),
      idx = keys.indexOf(activeGame);
    let target;
    if (e.key === 'ArrowRight') target = keys[(idx + 1) % keys.length];
    if (e.key === 'ArrowLeft') target = keys[(idx + keys.length - 1) % keys.length];
    if (e.key === 'Home') target = keys[0];
    if (e.key === 'End') target = keys.at(-1);
    if (target) {
      e.preventDefault();
      setGame(target);
      $('#game-' + target).focus();
    }
  };
});
function resetClock(e) {
  const last = e?.matches.at(-1),
    minutes = e ? matchMinutes(e, last) : GAMES[activeGame].minutes;
  seconds = (minutes || 0) * 60;
  drawClock();
  if (minutes === 0) $('#clock').textContent = 'Sem limite';
}
function syncTimer(e) {
  const key = activeGame + '/' + (e?.id || '') + '/' + (e?.matches.at(-1)?.round || 0);
  if (key === timerContext) return;
  timerContext = key;
  clearInterval(interval);
  interval = null;
  resetClock(e);
  $('#timer').textContent = 'Iniciar';
}
function renderStandings(e) {
  const scores = e
    ? isSwiss(e)
      ? swissStandings(e)
      : globalThis.calculateStandings(e)
    : [];
  const pct = (n) =>
    (n / 10).toLocaleString('pt-BR', {
      minimumFractionDigits: 1,
      maximumFractionDigits: 1,
    }) + '%';
  if (!scores.length) {
    $('#standings').innerHTML =
      '<p>Cadastre os participantes para acompanhar a classificação.</p>';
    return;
  }
  const swiss = isSwiss(e);
  const columns = swiss
    ? '<th>V–E–D</th><th>Pontos</th><th>Buchholz</th><th>Sonneborn–Berger</th><th>Byes</th>'
    : '<th>V–D</th><th>AA · Pontos</th><th>BBB · Oponentes</th><th>CCC · Op. dos op.</th><th>DDD · Σ R²</th><th>Código</th>';
  $('#standings').innerHTML =
    '<div class="ranking-scroll"><table><thead><tr><th>Pos.</th><th>Duelista</th>' +
    columns +
    '</tr></thead><tbody>' +
    scores
      .map(
        (p) => /* HTML */ `
          <tr>
            <td>${p.rank}${p.tied ? ' =' : ''}</td>
            <td>
              ${esc(p.name)}${p.tied
                ? '<small class="tie-label">Empate completo</small>'
                : ''}
            </td>
            ${swiss
              ? /* HTML */ `
                  <td>${p.wins}–${p.draws}–${p.losses}</td>
                  <td><b>${p.points}</b></td>
                  <td>${p.buchholz}</td>
                  <td>${p.sb.toLocaleString('pt-BR')}</td>
                  <td>${p.byes}</td>
                `
              : /* HTML */ `
                  <td>${p.wins}–${p.losses}</td>
                  <td><b>${p.points}</b></td>
                  <td>${pct(p.bbb)}</td>
                  <td>${pct(p.ccc)}</td>
                  <td>${p.ddd}</td>
                  <td><code>${p.code}</code></td>
                `}
          </tr>
        `,
      )
      .join('') +
    '</tbody></table></div>';
}
$('#generateRound').onclick = () => {
  if (!window.arenaCloud.isReady()) return notify('Aguarde a conexão com o banco.');
  const e = events.find((e) => e.id === current);
  if (!e) return;
  try {
    const matches = nextSwissRound(e);
    e.matches.push(...matches);
    save();
    $('#reset').click();
    notify('Rodada ' + matches[0].round + ' gerada.');
  } catch (error) {
    notify(error.message);
  }
};
render();

window.arenaCloud.start({
  getEvents: () => events,
  replaceEvents: (next) => {
    events = next;
    localStorage.setItem(eventStorageKey, JSON.stringify(events));
    render();
  },
});

import('./monthly.js');
