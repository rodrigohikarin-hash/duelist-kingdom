import { $, escapeOptionalHtml as esc } from './ui/dom.js';
import { hasCut, champion, matchLabel } from './top-cut.mjs';
import { GAMES, gameOf } from './swiss-core.mjs';
import QRCode from './qrcode-lib.mjs';
const cash = (n) =>
    (n / 100).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' }),
  params = new URLSearchParams(location.search),
  mode = params.get('mode') || 'player';
let store = params.get('store') || '',
  data = null,
  stores = [],
  loading = 0;
const selectedGame = params.get('game');
$('#leagueGame').innerHTML = Object.entries(GAMES)
  .map(
    ([id, g]) => /* HTML */ `
      <option value="${id}">${esc(g.name)}</option>
    `,
  )
  .join('');
if (Object.hasOwn(GAMES, selectedGame)) $('#leagueGame').value = selectedGame;
const dt = new Intl.DateTimeFormat('en-CA', {
  timeZone: 'America/Sao_Paulo',
  year: 'numeric',
  month: '2-digit',
}).formatToParts(new Date());
$('#leagueMonth').value = /^\d{4}-(0[1-9]|1[0-2])$/.test(params.get('month') || '')
  ? params.get('month')
  : dt.find((x) => x.type === 'year').value +
    '-' +
    dt.find((x) => x.type === 'month').value;
const roleNames = {
    owner: 'Proprietário',
    staff: 'Funcionário',
    judge: 'Juiz',
    player: 'Jogador',
    visitor: 'Visitante',
  },
  states = {
    confirmed: 'Confirmada',
    waitlisted: 'Lista de espera',
    checked: 'Presença confirmada',
    cancelled: 'Cancelada',
  },
  reportStates = {
    pending: 'Aguardando adversário',
    conflict: 'Divergência — arbitragem',
    applied: 'Resultado registrado',
  };
function status(t, error = false) {
  $('#leagueStatus').textContent = t;
  $('#leagueStatus').classList.toggle('error', error);
}
async function api(action, body = {}) {
  const r = await fetch(
    '/api/league' + (store ? '?store=' + encodeURIComponent(store) : ''),
    action
      ? {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action, ...body }),
        }
      : undefined,
  );
  const d = await r.json();
  if (!r.ok) throw Error(d.error || 'Não foi possível concluir.');
  return d;
}
async function run(fn, button) {
  if (button) button.disabled = true;
  try {
    await fn();
  } catch (e) {
    status(e.message, true);
    $('#leagueStatus').scrollIntoView({ block: 'nearest' });
  } finally {
    if (button) button.disabled = false;
  }
}
function enterStore(id) {
  store = id;
  const next = new URL(location.href);
  next.searchParams.set('store', id);
  history.replaceState(null, '', next);
  load();
}
async function list() {
  const r = await fetch('/api/league');
  const d = await r.json();
  if (!r.ok) throw Error(d.error);
  stores = d.stores;
  $('#storeCards').innerHTML = stores.length
    ? '<div class="store-cards">' +
      stores
        .map(
          (s) => /* HTML */ `
            <article class="store-card">
              <span class="eyebrow">
                ${esc(s.role ? roleNames[s.role] : 'COMUNIDADE')}
              </span>
              <h2>${esc(s.name)}</h2>
              <p>${esc(s.address || s.description || 'Uma nova comunidade de TCG.')}</p>
              <button class="primary" data-store="${esc(s.id)}">Abrir loja ↗</button>
            </article>
          `,
        )
        .join('') +
      '</div>'
    : '<div class="empty"><h3>Encontre sua comunidade</h3><p>As lojas que você participa ou que foram disponibilizadas aparecerão aqui. Você também pode aceitar um convite.</p></div>';
  document
    .querySelectorAll('[data-store]')
    .forEach((b) => (b.onclick = () => enterStore(b.dataset.store)));
  $('#createStore').hidden = mode === 'player';
  $('#legacyWorkspace').hidden = mode === 'player';
  status('Lojas atualizadas.');
}
async function load() {
  const version = ++loading;
  status('Atualizando dados…');
  $('#storePicker').hidden = !!store;
  $('#storeWorkspace').hidden = !store;
  try {
    if (!store) {
      await list();
      return;
    }
    const r = await fetch(
      '/api/league?store=' +
        encodeURIComponent(store) +
        '&game=' +
        $('#leagueGame').value +
        '&month=' +
        $('#leagueMonth').value,
    );
    const d = await r.json();
    if (version !== loading) return;
    if (!r.ok) throw Error(d.error);
    data = d;
    render();
    status('Dados atualizados · ' + roleNames[d.role]);
  } catch (e) {
    status(e.message, true);
    if (store) {
      $('#storeWorkspace').hidden = true;
      $('#storePicker').hidden = false;
      $('#storeCards').innerHTML =
        '<button class="secondary" id="returnList">Voltar às lojas</button>';
      $('#returnList').onclick = () => {
        store = '';
        history.replaceState(null, '', '/lojas.html?mode=' + mode);
        load();
      };
    }
  }
}
function render() {
  const s = data.store,
    admin = mode !== 'player' && ['owner', 'staff', 'judge'].includes(data.role),
    manage = mode !== 'player' && ['owner', 'staff'].includes(data.role),
    owner = mode !== 'player' && data.role === 'owner',
    game = $('#leagueGame').value,
    month = $('#leagueMonth').value;
  $('#storeName').textContent = s.name;
  $('#storeAddress').textContent = s.address;
  $('#storeDescription').textContent = s.description;
  $('#roleLabel').textContent = roleNames[data.role] + ' · COMUNIDADE DUELIST KINGDOM';
  $('#storeName').style.color = 'var(--ink)';
  document.querySelector('.store-heading').style.borderColor = s.brandColor;
  $('#storeAdmin').hidden = !owner;
  $('#openOrganizer').hidden = !admin;
  $('#joinStore').hidden = data.role !== 'visitor';
  $('#storeShare').href =
    location.origin +
    '/lojas.html?store=' +
    encodeURIComponent(store) +
    '&mode=player&game=' +
    game;
  const events = data.events
      .map((r) => r.event)
      .filter((e) => gameOf(e) === game && e.date.slice(0, 7) === month),
    eventIds = new Set(events.map((e) => e.id)),
    regs = data.registrations.filter((r) => eventIds.has(r.event)),
    attended = regs.filter((r) => r.checked),
    byUser = new Map();
  attended.forEach((r) => byUser.set(r.user, (byUser.get(r.user) || 0) + 1));
  const returning = [...byUser.values()].filter((n) => n > 1).length,
    settings = data.settings.filter((s) => eventIds.has(s.id)),
    revenue = regs.reduce((n, r) => n + r.paid, 0),
    expense = settings.reduce((n, s) => n + s.prizeCents + s.otherCents, 0),
    minutes = settings.reduce((n, s) => n + s.organizingMinutes, 0);
  $('#storeMetrics').innerHTML = manage
    ? /* HTML */ `
        <div class="stats metrics">
          <div>
            <p>
              Presenças confirmadas
              <strong>${attended.length}</strong>
              <small>${byUser.size} jogadores distintos</small>
            </p>
          </div>
          <div>
            <p>
              Retornaram no mês
              <strong>${returning}</strong>
              <small>
                ${byUser.size ? Math.round((returning / byUser.size) * 100) : 0}% dos
                presentes em mais de um evento
              </small>
            </p>
          </div>
          <div>
            <p>
              Receita registrada
              <strong>${cash(revenue)}</strong>
              <small>Pagamentos informados pela equipe</small>
            </p>
          </div>
          <div>
            <p>
              Saldo dos eventos
              <strong>${cash(revenue - expense)}</strong>
              <small>
                Custos: ${cash(expense)} · antes do orçamento mensal do software
              </small>
            </p>
          </div>
        </div>
        <p>
          Orçamento mensal do software para a loja: ${cash(s.subscription.monthlyCents)}
          (não incluído no saldo dos eventos). Organização registrada: ${minutes} min ·
          ${events.filter((e) => e.status === 'done').length} eventos concluídos ·
          ${s.subscription.eventCredits} créditos contratados (controle manual).
          Indicadores do jogo e mês selecionados; compare com sua rotina anterior.
        </p>
      `
    : '';
  $('#playerWallet').innerHTML = /* HTML */ `
    <div class="wallet">
      <span class="eyebrow">MEUS PONTOS DE FIDELIDADE NESTA LOJA</span>
      <strong>${data.balance} pontos</strong>
      <p>
        ${s.attendancePoints} pontos por presença confirmada + ${s.firstVisitBonus} de
        bônus na primeira participação. Pontos independentes da classificação competitiva.
      </p>
      <p>
        Seu ID vinculado à conta:
        <b>
          ${esc(
            'DK-' +
              data.user
                .replace(/[^A-Za-z0-9]/g, '')
                .toUpperCase()
                .slice(0, 32),
          )}
        </b>
      </p>
    </div>
  `;
  if (owner) {
    const f = $('#storeForm');
    for (const key of [
      'name',
      'address',
      'description',
      'brandColor',
      'attendancePoints',
      'firstVisitBonus',
    ])
      f.elements[key].value = s[key];
    f.elements.published.checked = s.published;
    f.elements.monthly.value = s.subscription.monthlyCents / 100;
    f.elements.eventCredits.value = s.subscription.eventCredits;
    f.elements.rewards.value = s.rewards.map((r) => r.name + ' | ' + r.cost).join('\n');
    $('#teamList').innerHTML = data.team
      .map(
        (t) => /* HTML */ `
          <div class="team-row">
            <code>${esc(t.user)}</code>
            <span>${esc(roleNames[t.role])}</span>
            ${t.role === 'owner'
              ? ''
              : /* HTML */ `
                  <select
                    aria-label="Perfil de ${esc(t.user)}"
                    data-member="${esc(t.user)}"
                  >
                    <option value="player" ${t.role === 'player' ? 'selected' : ''}>
                      Jogador
                    </option>
                    <option value="staff" ${t.role === 'staff' ? 'selected' : ''}>
                      Funcionário
                    </option>
                    <option value="judge" ${t.role === 'judge' ? 'selected' : ''}>
                      Juiz
                    </option>
                    <option value="remove">Remover acesso</option>
                  </select>
                  <button class="secondary" data-role-user="${esc(t.user)}">
                    Salvar perfil
                  </button>
                `}
          </div>
        `,
      )
      .join('');
  }
  $('#playerWallet').hidden = admin;
  const filter = $('#eventStatus').value;
  $('#leagueEvents').innerHTML =
    events
      .filter((e) => filter === 'all' || e.status === filter)
      .map((e) => {
        const mine = data.registrations.find(
            (r) => r.event === e.id && r.user === data.user,
          ),
          all = data.registrations.filter((r) => r.event === e.id),
          setting = data.settings.find((s) => s.id === e.id) || {
            feeCents: 0,
            prizeCents: 0,
            otherCents: 0,
            organizingMinutes: 0,
          },
          myPlayer = mine && e.players.find((p) => p.rankingId === mine.ranking_id),
          matches = myPlayer
            ? e.matches.filter((m) => [m.a, m.b].includes(myPlayer.id))
            : [];
        const hash = new URLSearchParams(location.hash.slice(1)),
          code = hash.get('event') === e.id ? hash.get('code') || '' : '';
        return /* HTML */ `
          <article class="league-event">
            <div class="section-head">
              <div>
                <h3>${esc(e.name)}</h3>
                <p>
                  ${esc(e.date.split('-').reverse().join('/'))} · ${esc(e.time)} ·
                  ${esc(e.location)}
                </p>
              </div>
              <span class="badge ${e.status}">
                ${{ open: 'Inscrições abertas', live: 'Em andamento', done: 'Encerrado' }[
                  e.status
                ]}
              </span>
            </div>
            <p>
              ${esc(e.format)} · ${e.players.length}/${e.capacity} participantes na lista
              de mesas · ${e.rounds} rodadas
              suíças${hasCut(e) && e.cutPlan.size
                ? ' · Top ' + e.cutPlan.size
                : ''}${champion(e)
                ? ' · Campeão: ' + esc(e.players.find((p) => p.id === champion(e))?.name)
                : ''}
              · Inscrição: ${cash(setting.feeCents)}
            </p>
            ${mine
              ? /* HTML */ `
                  <p><b>Minha inscrição: ${esc(states[mine.status])}</b></p>
                `
              : ''}${!mine && e.status === 'open' && data.role !== 'visitor'
              ? /* HTML */ `
                  <form class="actions" data-register="${esc(e.id)}">
                    <label>
                      Nome para inscrição
                      <input name="name" maxlength="80" required />
                    </label>
                    <button class="primary">Inscrever minha conta</button>
                  </form>
                `
              : ''}${mine &&
            ['confirmed', 'waitlisted'].includes(mine.status) &&
            e.status === 'open'
              ? /* HTML */ `
                  <button class="text" data-cancel="${esc(e.id)}">
                    Cancelar minha inscrição
                  </button>
                `
              : ''}${mine && mine.status === 'confirmed' && e.status !== 'done'
              ? /* HTML */ `
                  <form class="actions" data-checkin="${esc(e.id)}">
                    <label>
                      Código de presença (ou abra o QR da loja)
                      <input name="code" value="${esc(code)}" required maxlength="100" />
                    </label>
                    <button class="primary">Confirmar presença</button>
                  </form>
                `
              : ''}${matches.length
              ? '<h4>Minhas mesas</h4>' +
                matches
                  .map((m) => {
                    const opp = e.players.find(
                      (p) => p.id === (m.a === myPlayer.id ? m.b : m.a),
                    );
                    return /* HTML */ `
                      <div class="report-card">
                        <b>${matchLabel(e, m)} · Mesa ${m.table}</b>
                        <p>
                          ${opp ? 'Contra ' + esc(opp.name) : 'Bye'} ·
                          ${m.result
                            ? esc(
                                m.result === 'double'
                                  ? 'Derrota dupla'
                                  : m.result === 'draw'
                                    ? 'Empate'
                                    : m.result === 'bye' ||
                                        m.result === (m.a === myPlayer.id ? 'a' : 'b')
                                      ? 'Vitória'
                                      : 'Derrota',
                              )
                            : 'Aguardando resultado'}
                        </p>
                        ${!m.result && e.status === 'live' && m.b
                          ? /* HTML */ `
                              <form
                                data-result="${esc(e.id)}"
                                data-round="${m.round}"
                                data-table="${m.table}"
                                class="inline"
                              >
                                <label>
                                  Resultado
                                  <select name="result">
                                    <option value="${m.a === myPlayer.id ? 'a' : 'b'}">
                                      Minha vitória
                                    </option>
                                    <option value="${m.a === myPlayer.id ? 'b' : 'a'}">
                                      Vitória do adversário
                                    </option>
                                    ${game !== 'yugioh' && m.phase !== 'cut'
                                      ? '<option value="draw">Empate</option>'
                                      : ''}
                                  </select>
                                </label>
                                <button class="secondary">
                                  Enviar / confirmar resultado
                                </button>
                              </form>
                            `
                          : ''}
                      </div>
                    `;
                  })
                  .join('')
              : ''}${manage
              ? /* HTML */ `
                  <details>
                    <summary>Inscrições, presença e pagamentos (${all.length})</summary>
                    <div class="actions">
                      <button class="primary" data-import="${esc(e.id)}">
                        Importar confirmados para as mesas
                      </button>
                      <button class="secondary" data-qr="${esc(e.id)}">
                        Gerar QR de presença
                      </button>
                    </div>
                    <div id="qr-${esc(e.id)}"></div>
                    <div class="ranking-scroll">
                      <table>
                        <thead>
                          <tr>
                            <th>Jogador</th>
                            <th>Situação</th>
                            <th>Recebido</th>
                            <th>Ações</th>
                          </tr>
                        </thead>
                        <tbody>
                          ${all
                            .map(
                              (r) => /* HTML */ `
                                <tr>
                                  <td>
                                    ${esc(r.name)}
                                    <br />
                                    <small>${esc(r.ranking_id)}</small>
                                  </td>
                                  <td>${esc(states[r.status])}</td>
                                  <td>
                                    <input
                                      aria-label="Pagamento de ${esc(r.name)}"
                                      type="number"
                                      min="0"
                                      step="0.01"
                                      value="${r.paid / 100}"
                                      data-paid="${esc(e.id + '|' + r.user)}"
                                    />
                                  </td>
                                  <td>
                                    <button
                                      class="text"
                                      data-payment="${esc(e.id + '|' + r.user)}"
                                    >
                                      Salvar pagamento
                                    </button>
                                    ${r.status === 'confirmed'
                                      ? /* HTML */ `
                                          <button
                                            class="text"
                                            data-attendance="${esc(e.id + '|' + r.user)}"
                                          >
                                            Confirmar presença
                                          </button>
                                        `
                                      : ''}${r.status === 'waitlisted'
                                      ? /* HTML */ `
                                          <button
                                            class="text"
                                            data-promote="${esc(e.id + '|' + r.user)}"
                                          >
                                            Promover da fila
                                          </button>
                                        `
                                      : ''}
                                  </td>
                                </tr>
                              `,
                            )
                            .join('')}
                        </tbody>
                      </table>
                    </div>
                  </details>
                  <details>
                    <summary>Valores e tempo de organização</summary>
                    <form class="inline" data-settings="${esc(e.id)}">
                      <label>
                        Inscrição (R$)
                        <input
                          name="fee"
                          type="number"
                          min="0"
                          step="0.01"
                          value="${setting.feeCents / 100}"
                          required
                        />
                      </label>
                      <label>
                        Premiação (R$)
                        <input
                          name="prize"
                          type="number"
                          min="0"
                          step="0.01"
                          value="${setting.prizeCents / 100}"
                          required
                        />
                      </label>
                      <label>
                        Outros custos (R$)
                        <input
                          name="other"
                          type="number"
                          min="0"
                          step="0.01"
                          value="${setting.otherCents / 100}"
                          required
                        />
                      </label>
                      <label>
                        Organização (min)
                        <input
                          name="minutes"
                          type="number"
                          min="0"
                          value="${setting.organizingMinutes}"
                          required
                        />
                      </label>
                      <button class="secondary">Salvar</button>
                    </form>
                  </details>
                `
              : ''}
          </article>
        `;
      })
      .join('') ||
    '<div class="empty"><p>Nenhum torneio neste jogo e mês. A organização pode criar novos eventos no painel de torneios.</p></div>';
  const rows = data.ranking.standings;
  $('#leagueRanking').innerHTML = rows.length
    ? /* HTML */ `
        <div class="ranking-scroll">
          <table>
            <thead>
              <tr>
                <th>Pos.</th>
                <th>Jogador</th>
                <th>Título</th>
                <th>Pontos</th>
                <th>Torneios</th>
                <th>V–E–D</th>
              </tr>
            </thead>
            <tbody>
              ${rows
                .map(
                  (p) => /* HTML */ `
                    <tr>
                      <td>${p.rank}</td>
                      <td>${esc(p.name)}</td>
                      <td>
                        ${p.monthlyTitle
                          ? /* HTML */ `
                              <span class="monthly-tier tier-${esc(p.monthlyTitle.id)}">
                                ${esc(p.monthlyTitle.label)}
                              </span>
                            `
                          : '—'}
                      </td>
                      <td>${p.points}</td>
                      <td>${p.events}</td>
                      <td>${p.wins}–${p.draws || 0}–${p.losses}</td>
                    </tr>
                  `,
                )
                .join('')}
            </tbody>
          </table>
        </div>
        <p>
          Pokémon e One Piece têm um campeão e no máximo quatro integrantes na faixa
          seguinte. Os títulos usam pontos, vitórias, aproveitamento, menos derrotas e ID.
        </p>
      `
    : '<p>Encerre um torneio neste mês para iniciar a classificação.</p>';
  $('#rewardList').innerHTML = s.rewards.length
    ? '<div class="reward-grid">' +
      s.rewards
        .map(
          (r) => /* HTML */ `
            <article class="reward">
              <h3>${esc(r.name)}</h3>
              <p>${r.cost} pontos</p>
              <button
                class="secondary"
                data-reward="${esc(r.id)}"
                ${data.balance < r.cost || data.role === 'visitor' ? 'disabled' : ''}
              >
                Solicitar resgate
              </button>
            </article>
          `,
        )
        .join('') +
      '</div>'
    : '<p>A loja ainda não cadastrou recompensas.</p>';
  $('#redemptionList').innerHTML = data.redemptions
    .map(
      (r) => /* HTML */ `
        <div class="team-row">
          <span>
            ${esc(r.reward)} · ${r.cost} pontos ·
            ${r.status === 'delivered'
              ? 'Entregue'
              : r.status === 'cancelled'
                ? 'Cancelado e pontos devolvidos'
                : 'Aguardando entrega'}
          </span>
          ${manage && r.status === 'pending'
            ? /* HTML */ `
                <button class="secondary" data-fulfill="${esc(r.id)}">
                  Confirmar entrega
                </button>
                <button class="text" data-refund="${esc(r.id)}">
                  Cancelar e devolver pontos
                </button>
              `
            : ''}
        </div>
      `,
    )
    .join('');
  $('#loyaltyHistory').innerHTML =
    data.ledger
      .map(
        (l) => /* HTML */ `
          <div class="loyalty-row">
            <span>
              ${esc(l.description)}
              <br />
              <small>${esc(l.created.slice(0, 10))}</small>
            </span>
            <b>${l.points > 0 ? '+' : ''}${l.points} pts</b>
          </div>
        `,
      )
      .join('') ||
    '<p>Seu histórico de pontos aparecerá após a primeira presença confirmada.</p>';
  $('#reportsSection').hidden = !data.reports.some((r) => eventIds.has(r.event));
  $('#reportList').innerHTML = data.reports
    .filter((r) => eventIds.has(r.event))
    .map(
      (r) => /* HTML */ `
        <div class="report-card">
          <b>
            ${esc(events.find((e) => e.id === r.event)?.name)} · R${r.round} / Mesa
            ${r.table}
          </b>
          <p>${esc(r.aName)} × ${esc(r.bName)} · ${esc(reportStates[r.status])}</p>
          ${admin && r.status !== 'applied'
            ? /* HTML */ `
                <form
                  class="inline"
                  data-resolve="${esc(r.event)}"
                  data-round="${r.round}"
                  data-table="${r.table}"
                >
                  <label>
                    Decisão da arbitragem
                    <select name="result">
                      <option value="a">Vitória: ${esc(r.aName)}</option>
                      <option value="b">Vitória: ${esc(r.bName)}</option>
                      ${game === 'yugioh'
                        ? '<option value="double">Derrota dupla</option>'
                        : '<option value="draw">Empate</option>'}
                    </select>
                  </label>
                  <button class="secondary">Aplicar decisão</button>
                </form>
              `
            : ''}
        </div>
      `,
    )
    .join('');
  bind();
}
function cents(value) {
  return Math.round(Number(value) * 100);
}
function bind() {
  const clicks = (selector, fn) =>
    document
      .querySelectorAll(selector)
      .forEach((b) => (b.onclick = () => run(() => fn(b), b)));
  const forms = (selector, fn) =>
    document.querySelectorAll(selector).forEach(
      (f) =>
        (f.onsubmit = (e) => {
          e.preventDefault();
          run(() => fn(f), f.querySelector('button'));
        }),
    );
  const mutate = async (action, b) => {
    const r = await api(action, b);
    await load();
    if (r.message) status(r.message);
    return r;
  };
  forms('[data-register]', (f) =>
    mutate('register', { event: f.dataset.register, name: f.elements.name.value }),
  );
  forms('[data-checkin]', (f) =>
    mutate('checkin', { event: f.dataset.checkin, code: f.elements.code.value.trim() }),
  );
  clicks('[data-cancel]', (b) =>
    mutate('cancel-registration', { event: b.dataset.cancel }),
  );
  clicks('[data-import]', (b) =>
    mutate('import-registrations', { event: b.dataset.import }),
  );
  clicks('[data-attendance]', (b) => {
    const [event, user] = b.dataset.attendance.split('|');
    return mutate('checkin', { event, user });
  });
  clicks('[data-promote]', (b) => {
    const [event, user] = b.dataset.promote.split('|');
    return mutate('promote', { event, user });
  });
  clicks('[data-payment]', (b) => {
    const [event, user] = b.dataset.payment.split('|'),
      input = [...document.querySelectorAll('[data-paid]')].find(
        (x) => x.dataset.paid === b.dataset.payment,
      );
    return mutate('payment', { event, user, paidCents: cents(input.value) });
  });
  forms('[data-settings]', (f) =>
    mutate('event-settings', {
      event: f.dataset.settings,
      feeCents: cents(f.elements.fee.value),
      prizeCents: cents(f.elements.prize.value),
      otherCents: cents(f.elements.other.value),
      organizingMinutes: Number(f.elements.minutes.value),
    }),
  );
  forms('[data-result]', (f) =>
    mutate('report-result', {
      event: f.dataset.result,
      round: +f.dataset.round,
      table: +f.dataset.table,
      result: f.elements.result.value,
    }),
  );
  forms('[data-resolve]', (f) =>
    mutate('resolve-report', {
      event: f.dataset.resolve,
      round: +f.dataset.round,
      table: +f.dataset.table,
      result: f.elements.result.value,
    }),
  );
  clicks('[data-role-user]', (b) => {
    const input = [...document.querySelectorAll('[data-member]')].find(
      (x) => x.dataset.member === b.dataset.roleUser,
    );
    return mutate('member-role', { user: b.dataset.roleUser, role: input.value });
  });
  clicks('[data-reward]', (b) =>
    mutate('redeem', { reward: b.dataset.reward, requestId: crypto.randomUUID() }),
  );
  clicks('[data-fulfill]', (b) => mutate('fulfill', { id: b.dataset.fulfill }));
  clicks('[data-refund]', (b) => mutate('refund-redemption', { id: b.dataset.refund }));
  clicks('[data-qr]', async (b) => {
    const r = await api('checkin-code', { event: b.dataset.qr }),
      link = new URL('/lojas.html', location.origin);
    link.searchParams.set('store', store);
    link.searchParams.set('mode', 'player');
    const ev = data.events.find((x) => x.event.id === b.dataset.qr).event;
    link.searchParams.set('game', gameOf(ev));
    link.searchParams.set('month', ev.date.slice(0, 7));
    link.hash = new URLSearchParams({ event: b.dataset.qr, code: r.code }).toString();
    const image = await QRCode.toDataURL(link.href, { width: 240, margin: 2 });
    document.getElementById('qr-' + b.dataset.qr).innerHTML = /* HTML */ `
      <div class="qr-box">
        <img src="${image}" alt="QR Code para confirmar presença" />
        <p>Válido por 120 minutos. Exiba no local do evento.</p>
        <label>
          Link de presença
          <input readonly value="${esc(link.href)}" />
        </label>
        <label>
          Código
          <input readonly value="${esc(r.code)}" />
        </label>
      </div>
    `;
  });
}
$('#createStore').onsubmit = (e) => {
  e.preventDefault();
  run(async () => {
    const d = await api('create-store', { name: e.target.elements.name.value });
    enterStore(d.id);
  }, e.submitter);
};
$('#joinInvite').onsubmit = (e) => {
  e.preventDefault();
  run(async () => {
    const d = await api('accept-invite', { token: e.target.elements.token.value.trim() });
    enterStore(d.id);
  }, e.submitter);
};
$('#storeForm').onsubmit = (e) => {
  e.preventDefault();
  run(async () => {
    const f = e.target.elements,
      rewards = f.rewards.value
        .split('\n')
        .filter((s) => s.trim())
        .map((line, i) => {
          const [name, cost] = line.split('|');
          if (!name || !cost || !Number.isInteger(Number(cost)) || Number(cost) < 1)
            throw Error('Use nome | pontos em cada recompensa.');
          return {
            id:
              data.store.rewards.find((r) => r.name === name.trim())?.id ||
              crypto.randomUUID(),
            name: name.trim(),
            cost: Number(cost),
          };
        });
    await api('save-store', {
      revision: data.store.revision,
      name: f.name.value,
      address: f.address.value,
      description: f.description.value,
      brandColor: f.brandColor.value,
      published: f.published.checked,
      attendancePoints: +f.attendancePoints.value,
      firstVisitBonus: +f.firstVisitBonus.value,
      rewards,
      monthlyCents: cents(f.monthly.value),
      eventCredits: +f.eventCredits.value,
    });
    await load();
    status('Configurações salvas.');
  }, e.submitter);
};
$('#inviteForm').onsubmit = (e) => {
  e.preventDefault();
  run(async () => {
    const r = await api('invite', { role: e.target.elements.role.value });
    $('#inviteResult').innerHTML = /* HTML */ `
      <p>
        Convite de ${esc(roleNames[r.role])}, válido por sete dias. Compartilhe somente
        com a pessoa que receberá esse acesso.
      </p>
      <input readonly aria-label="Código de convite" value="${esc(r.token)}" />
    `;
  }, e.submitter);
};
$('#openOrganizer').onclick = () => {
  localStorage.setItem('kingdom-store', store);
  localStorage.setItem('duel-arena-game', document.getElementById('leagueGame').value);
  location.href = '/organizador';
};
$('#legacyWorkspace').onclick = () => localStorage.removeItem('kingdom-store');
$('#joinStore').onclick = () =>
  run(async () => {
    await api('join');
    await load();
  }, $('#joinStore'));
$('#reloadStore').onclick = () => run(load, $('#reloadStore'));
$('#backStores').onclick = () => {
  store = '';
  history.replaceState(null, '', '/lojas.html?mode=' + mode);
  load();
};
$('#leagueGame').onchange = load;
$('#leagueMonth').onchange = load;
$('#eventStatus').onchange = () => data && render();
load();
