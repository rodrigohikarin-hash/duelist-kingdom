import { escapeOptionalHtml as esc } from './ui/dom.js';
import {
  CUT_RULES,
  hasCut,
  swissMatches,
  cutMatches,
  recommendedCut,
  checkCutPlan,
  swissComplete,
  firstCutRound,
  nextCutRound,
  champion,
  cutComplete,
  matchLabel,
  matchMinutes,
} from './top-cut.mjs';
export {
  hasCut,
  swissMatches,
  cutMatches,
  checkCutPlan,
  champion,
  matchLabel,
  matchMinutes,
};

const fields = (game, plan = {}, rounds = 5) => /* HTML */ `
  <label>
    Perfil de regras
    <select name="cutProfile">
      <option value="base">Tabela base do jogo</option>
      <option value="event">Regulamento específico do evento</option>
    </select>
  </label>
  <label>
    Participantes previstos / confirmados
    <input
      name="expectedPlayers"
      type="number"
      min="4"
      max="2048"
      value="${plan.expectedPlayers || 32}"
      required
    />
  </label>
  <div class="inline">
    <label>
      Rodadas suíças
      <input name="cutRounds" type="number" min="1" max="20" value="${rounds}" required />
    </label>
    <label>
      Corte
      <select name="cutSize">
        ${[0, 2, 4, 8, 16, 32]
          .map(
            (n) => /* HTML */ `
              <option value="${n}">
                ${n ? 'Top ' + n : 'Sem corte (faixa de participantes)'}
              </option>
            `,
          )
          .join('')}
      </select>
    </label>
  </div>
  <div class="inline">
    <label>
      Top Cut (min; 0 = sem limite)
      <input
        name="cutMinutes"
        type="number"
        min="0"
        max="180"
        value="${plan.minutes ?? CUT_RULES[game].cut}"
        required
      />
    </label>
    <label>
      Final (min; 0 = sem limite)
      <input
        name="finalMinutes"
        type="number"
        min="0"
        max="180"
        value="${plan.finalMinutes ?? CUT_RULES[game].final}"
        required
      />
    </label>
  </div>
  <label>
    Regulamento / Ops Doc / divisão
    <input
      name="cutReference"
      maxlength="500"
      value="${esc(plan.reference || '')}"
      placeholder="URL, versão e divisão etária, se aplicável"
    />
  </label>
  <p class="notice" data-plan-summary></p>
`;
function wire(form, game, plan) {
  const q = (n) => form.elements[n];
  q('cutProfile').value = plan?.profile || (game === 'pokemon' ? 'event' : 'base');
  q('cutSize').value = plan?.size ?? 8;
  function update() {
    const base = q('cutProfile').value === 'base',
      rule = CUT_RULES[game];
    let message = rule.note;
    if (game === 'pokemon' && base) {
      q('cutProfile').value = 'event';
      return update();
    }
    if (base) {
      try {
        const r = recommendedCut(game, +q('expectedPlayers').value);
        q('cutRounds').value = r.rounds;
        q('cutSize').value = r.size;
        q('cutMinutes').value = rule.cut;
        q('finalMinutes').value = rule.final;
        if (q('roundMinutes')) q('roundMinutes').value = rule.swiss;
        message =
          `${r.rounds} rodadas suíças · ${r.size ? 'Top ' + r.size : 'sem corte nesta faixa'}. ` +
          message;
      } catch (e) {
        message = e.message;
      }
    }
    for (const name of ['cutRounds', 'cutSize', 'cutMinutes', 'finalMinutes']) {
      q(name).disabled = base;
    }
    if (q('roundMinutes')) q('roundMinutes').readOnly = base;
    q('cutReference').required = !base;
    form.querySelector('[data-plan-summary]').textContent = message;
  }
  q('cutProfile').onchange = q('expectedPlayers').oninput = update;
  update();
}
export function initCutForm(form, game) {
  let box = form.querySelector('[data-create-cut]');
  if (!box) {
    box = document.createElement('fieldset');
    box.dataset.createCut = '';
    form.querySelector('[name=rounds]').closest('label').after(box);
    const label = document.createElement('label');
    label.innerHTML =
      '<span>Modalidade</span><select name="structure"><option value="swiss">Somente suíço</option><option value="swiss-cut">Suíço + Top Cut</option></select>';
    box.before(label);
  }
  box.innerHTML = '<legend>Planejamento do Top Cut</legend>' + fields(game);
  wire(form, game);
  const update = () => {
    const active = form.elements.structure.value === 'swiss-cut';
    box.hidden = !active;
    box.disabled = !active;
    form.elements.rounds.closest('label').hidden = active;
    if (!active) form.elements.roundMinutes.readOnly = false;
    else form.elements.cutProfile.onchange();
  };
  form.elements.structure.onchange = update;
  update();
}
function planFrom(form) {
  return {
    profile: form.elements.cutProfile.value,
    expectedPlayers: +form.elements.expectedPlayers.value,
    size: +form.elements.cutSize.value,
    minutes: +form.elements.cutMinutes.value,
    finalMinutes: +form.elements.finalMinutes.value,
    reference: form.elements.cutReference.value.trim(),
  };
}
export function readCutForm(form, e) {
  e.structure = form.elements.structure.value;
  if (hasCut(e)) {
    e.cutPlan = planFrom(form);
    e.rounds = +form.elements.cutRounds.value;
    checkCutPlan(e);
  }
  return e;
}
export function canFinish(e) {
  if (!hasCut(e)) return e.matches.every((m) => m.result);
  return swissComplete(e) && (!e.cutPlan.size || cutComplete(e));
}
export function renderCut(e, { container, save, notify }) {
  if (!e || !hasCut(e)) {
    container.hidden = true;
    return;
  }
  container.hidden = false;
  const rule = CUT_RULES[e.game ?? 'yugioh'],
    cut = cutMatches(e),
    winner = champion(e),
    name = (id) => e.players.find((p) => p.id === id)?.name || 'Vaga sem classificado',
    swissDone = swissComplete(e),
    judge = document.body.dataset.storeRole === 'judge';
  container.innerHTML = /* HTML */ `
    <div class="cut-heading">
      <div>
        <div class="eyebrow">CAMINHO ATÉ O TÍTULO</div>
        <h2>
          Suíço
          <span>→</span>
          ${e.cutPlan.size ? 'Top ' + e.cutPlan.size : 'classificação final'}
        </h2>
        <p>
          ${e.rounds} rodadas · ${e.cutPlan.expectedPlayers} participantes ·
          ${esc(rule.label)}
        </p>
      </div>
      <span class="badge">
        ${winner
          ? 'Campeão definido'
          : cut.length
            ? 'Eliminatórias'
            : swissDone
              ? 'Suíço concluído'
              : 'Fase suíça'}
      </span>
    </div>
    <p>
      <a href="${rule.url}" target="_blank" rel="noopener">Consultar diretrizes ↗</a>
    </p>
    <p>${esc(rule.note)}</p>
    <p class="notice">
      Ranking mensal da liga: somente pontos da fase suíça. O Top Cut define o campeão do
      torneio e não acrescenta pontos ao mês.
    </p>
    ${e.cutPlan.reference
      ? '<p>Documento anunciado: ' + esc(e.cutPlan.reference) + '</p>'
      : ''}
  `;
  if (e.status === 'open' && !judge) {
    const form = document.createElement('form');
    form.className = 'cut-plan';
    form.innerHTML =
      '<h3>Confirmar plano antes de iniciar</h3><p>Use a quantidade real de inscritos. Rodadas, corte e tempos ficam fixos após o início.</p>' +
      fields(e.game ?? 'yugioh', e.cutPlan, e.rounds) +
      '<button class="secondary">Salvar plano anunciado</button>';
    container.append(form);
    wire(form, e.game ?? 'yugioh', e.cutPlan);
    form.onsubmit = (ev) => {
      ev.preventDefault();
      try {
        const next = {
          ...e,
          cutPlan: planFrom(form),
          rounds: +form.elements.cutRounds.value,
        };
        if (next.cutPlan.profile === 'base') next.roundMinutes = rule.swiss;
        checkCutPlan(next);
        Object.assign(e, next);
        save();
        notify('Plano atualizado. Anuncie aos participantes antes de iniciar.');
      } catch (error) {
        notify(error.message);
      }
    };
    return;
  }
  if (winner) {
    container.insertAdjacentHTML(
      'beforeend',
      /* HTML */ `
        <div class="cut-champion">
          <span>♛</span>
          <div>
            <small>CAMPEÃO DO TORNEIO</small>
            <h3>${esc(name(winner))}</h3>
            <p>Vencedor da final · seed ${e.cutSeeds.indexOf(winner) + 1}</p>
          </div>
        </div>
      `,
    );
  }
  if (!cut.length && e.cutPlan.size && e.status === 'live' && !judge) {
    if (!swissDone) {
      container.insertAdjacentHTML(
        'beforeend',
        '<p>Conclua todas as mesas das rodadas suíças para confirmar os classificados.</p>',
      );
      return;
    }
    const form = document.createElement('form');
    form.className = 'cut-seeding';
    form.innerHTML = /* HTML */ `
      <h3>Homologar os classificados</h3>
      <p>
        Selecione os ${e.cutPlan.size} classificados em ordem, do seed 1 ao
        ${e.cutPlan.size}. Use a classificação oficial do evento (TOM, TCG+, Play Hub ou
        KTS, quando exigido). Buchholz/SB do perfil de liga não substitui os desempates
        oficiais. A arbitragem deve resolver empates que afetem o corte ou o seeding.
      </p>
      <div class="cut-seeds">
        ${Array.from(
          { length: e.cutPlan.size },
          (_, i) => /* HTML */ `
            <label>
              Seed ${i + 1}
              <select name="seed${i}" required>
                <option value="">Escolha o classificado</option>
                ${e.players
                  .map(
                    (p) => /* HTML */ `
                      <option value="${esc(p.id)}">
                        ${esc(p.name)} · ${esc(p.rankingId || p.id)}
                      </option>
                    `,
                  )
                  .join('')}
              </select>
            </label>
          `,
        ).join('')}
      </div>
      <label>
        Homologação da arbitragem
        <input
          name="approval"
          required
          minlength="3"
          maxlength="500"
          placeholder="Ex.: classificação final do TCG+ conferida pelo juiz"
        />
      </label>
      <label class="cut-check">
        <input type="checkbox" required />
        Conferi a classificação, os desempates e a ordem dos seeds.
      </label>
      <button class="primary">Confirmar classificados e abrir Top Cut</button>
    `;
    container.append(form);
    form.onsubmit = (ev) => {
      ev.preventDefault();
      try {
        const seeds = Array.from(
            { length: e.cutPlan.size },
            (_, i) => form.elements['seed' + i].value,
          ),
          matches = firstCutRound(e, seeds);
        e.cutSeeds = seeds;
        e.cutApproval = form.elements.approval.value.trim();
        e.matches.push(...matches);
        save();
        notify('Chave aberta com seeds homologados.');
      } catch (error) {
        notify(error.message);
      }
    };
  }
  if (cutComplete(e) && !winner)
    container.insertAdjacentHTML(
      'beforeend',
      '<p class="notice">Torneio concluído sem campeão: não restaram classificados após as eliminações duplas.</p>',
    );
  if (cut.length) {
    const rounds = [...new Set(cut.map((m) => m.round))].sort((a, b) => a - b);
    container.insertAdjacentHTML(
      'beforeend',
      /* HTML */ `
        <div class="cut-bracket">
          ${rounds
            .map((r) => {
              const ms = cut
                  .filter((m) => m.round === r)
                  .sort((a, b) => a.table - b.table),
                minutes = matchMinutes(e, ms[0]);
              return /* HTML */ `
                <section class="cut-column">
                  <h3>${matchLabel(e, ms[0])}</h3>
                  <p>${minutes ? minutes + ' min' : 'Sem limite de tempo'} · Bo3</p>
                  ${ms
                    .map(
                      (m) => /* HTML */ `
                        <div class="cut-match">
                          <small>Mesa ${m.table}</small>
                          ${['a', 'b']
                            .map(
                              (side) => /* HTML */ `
                                <div
                                  class="cut-contender ${m.result === side
                                    ? 'cut-winner'
                                    : ''}"
                                >
                                  <span>
                                    #${m[side] ? e.cutSeeds.indexOf(m[side]) + 1 : '—'}
                                  </span>
                                  <b>${esc(name(m[side]))}</b>
                                  ${m.result === side ? ' ✓' : ''}
                                </div>
                              `,
                            )
                            .join('')}${!['bye', 'void'].includes(m.result)
                            ? /* HTML */ `
                                <select
                                  data-cut-result="${e.matches.indexOf(m)}"
                                  aria-label="Resultado ${matchLabel(
                                    e,
                                    m,
                                  )}, mesa ${m.table}"
                                  ${e.status === 'done' ||
                                  cut.some((next) => next.round > m.round)
                                    ? 'disabled'
                                    : ''}
                                >
                                  <option value="">Resultado pendente</option>
                                  <option value="a">Vitória de ${esc(name(m.a))}</option>
                                  <option value="b">Vitória de ${esc(name(m.b))}</option>
                                  ${(e.game ?? 'yugioh') === 'yugioh' &&
                                  m.round < e.rounds + Math.log2(e.cutPlan.size)
                                    ? '<option value="double">Derrota dupla · ambos eliminados</option>'
                                    : ''}
                                </select>
                              `
                            : ''}
                          <small>
                            ${m.result === 'double'
                              ? 'Derrota dupla · ambos eliminados'
                              : m.result === 'bye'
                                ? 'Avanço por bye'
                                : m.result === 'void'
                                  ? 'Vaga sem classificado'
                                  : m.result
                                    ? 'Resultado confirmado'
                                    : 'Resultado pendente'}
                          </small>
                        </div>
                      `,
                    )
                    .join('')}
                </section>
              `;
            })
            .join('')}
        </div>
      `,
    );
    container.querySelectorAll('[data-cut-result]').forEach((select) => {
      select.value = e.matches[+select.dataset.cutResult].result;
      select.onchange = () => {
        e.matches[+select.dataset.cutResult].result = select.value;
        save();
      };
    });
    const last = cut.filter((m) => m.round === Math.max(...rounds));
    if (!cutComplete(e) && last.every((m) => m.result) && e.status === 'live' && !judge) {
      const b = document.createElement('button');
      b.className = 'primary';
      b.textContent = 'Gerar próxima fase eliminatória';
      container.append(b);
      b.onclick = () => {
        try {
          e.matches.push(...nextCutRound(e));
          save();
          notify('Próxima fase publicada.');
        } catch (error) {
          notify(error.message);
        }
      };
    }
    if (e.status === 'live' && !judge) {
      const reset = document.createElement('button');
      reset.className = 'text';
      reset.textContent = 'Reabrir classificação e refazer o corte';
      container.append(reset);
      reset.onclick = () => {
        if (
          !confirm(
            'Isso removerá a chave e todos os resultados eliminatórios deste torneio. As rodadas suíças serão preservadas. Continuar?',
          )
        )
          return;
        e.matches = swissMatches(e);
        delete e.cutSeeds;
        delete e.cutApproval;
        save();
        notify('Corte removido. Corrija o suíço e homologue os classificados novamente.');
      };
    }
  }
}
